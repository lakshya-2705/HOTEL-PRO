require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');
const Room = require('./models/Room');

(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  await Promise.all([User.deleteMany({}), Room.deleteMany({})]);

  await User.create({ name: 'Admin', email: 'admin@hotelpro.com', password: 'admin123', role: 'admin' });

  await Room.insertMany([
    { number: '101', type: 'single', price: 1500, capacity: 1, amenities: ['WiFi', 'AC'], description: 'Cozy single room.' },
    { number: '102', type: 'double', price: 2500, capacity: 2, amenities: ['WiFi', 'AC', 'TV'], description: 'Comfortable double room.' },
    { number: '201', type: 'deluxe', price: 4000, capacity: 3, amenities: ['WiFi', 'AC', 'TV', 'Mini Bar'], description: 'Spacious deluxe room with city view.' },
    { number: '301', type: 'suite', price: 7500, capacity: 4, amenities: ['WiFi', 'AC', 'TV', 'Mini Bar', 'Jacuzzi'], description: 'Luxury suite with living area.' },
  ]);

  console.log('Seeded. Admin login: admin@hotelpro.com / admin123');
  process.exit(0);
})();
