import { Link } from 'react-router-dom';

const features = [
  ['📅', 'Easy Booking', 'Real-time availability and instant reservations.'],
  ['🔐', 'Secure Access', 'JWT authentication with encrypted passwords.'],
  ['💳', 'Payments', 'Track payment status for every booking.'],
  ['📈', 'Scalable', 'Built to grow from boutique stays to large chains.'],
];

export default function Home() {
  return (
    <>
      <section className="hero text-center">
        <div className="container">
          <h1 className="display-4 fw-bold">Your ultimate hotel management solution</h1>
          <p className="lead mt-3">Secure, scalable and simple: bookings, guests and payments in one place.</p>
          <Link to="/rooms" className="btn btn-light btn-lg mt-3">Browse Rooms</Link>
        </div>
      </section>
      <div className="container py-5">
        <div className="row g-4">
          {features.map(([icon, title, text]) => (
            <div className="col-md-6 col-lg-3" key={title}>
              <div className="card h-100 shadow-sm text-center p-3">
                <div className="fs-1">{icon}</div>
                <h5 className="mt-2">{title}</h5>
                <p className="text-muted mb-0">{text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
