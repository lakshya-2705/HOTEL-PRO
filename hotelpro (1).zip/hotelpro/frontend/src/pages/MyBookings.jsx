import { useEffect, useState } from 'react';
import api, { errMsg } from '../api';

const statusColor = { booked: 'primary', 'checked-in': 'success', 'checked-out': 'secondary', cancelled: 'danger' };
const fmt = (d) => new Date(d).toLocaleDateString();

export default function MyBookings() {
  const [bookings, setBookings] = useState([]);
  const [error, setError] = useState('');

  const load = async () => {
    try {
      const { data } = await api.get('/bookings/mine');
      setBookings(data);
    } catch (err) {
      setError(errMsg(err));
    }
  };

  useEffect(() => {
    load();
  }, []);

  const act = async (id, action, body = {}) => {
    try {
      await api.put(`/bookings/${id}/${action}`, body);
      load();
    } catch (err) {
      setError(errMsg(err));
    }
  };

  return (
    <div className="container py-4">
      <h2 className="mb-3">My bookings</h2>
      {error && <div className="alert alert-danger">{error}</div>}
      <div className="table-responsive">
        <table className="table table-hover align-middle bg-white">
          <thead>
            <tr><th>Room</th><th>Dates</th><th>Total</th><th>Status</th><th>Payment</th><th></th></tr>
          </thead>
          <tbody>
            {bookings.map((b) => (
              <tr key={b._id}>
                <td>{b.room?.number} ({b.room?.type})</td>
                <td>{fmt(b.checkIn)} → {fmt(b.checkOut)}</td>
                <td>₹{b.totalPrice}</td>
                <td><span className={`badge bg-${statusColor[b.status]}`}>{b.status}</span></td>
                <td>{b.payment.status}</td>
                <td className="text-end">
                  {b.status !== 'cancelled' && b.payment.status === 'pending' && (
                    <button className="btn btn-sm btn-success me-2" onClick={() => act(b._id, 'pay', { method: 'card' })}>Pay now</button>
                  )}
                  {b.status === 'booked' && (
                    <button className="btn btn-sm btn-outline-danger" onClick={() => act(b._id, 'cancel')}>Cancel</button>
                  )}
                </td>
              </tr>
            ))}
            {bookings.length === 0 && <tr><td colSpan="6" className="text-muted">No bookings yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
