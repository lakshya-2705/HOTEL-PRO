import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function ProtectedRoute({ children, staff = false }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="container py-5">Loading...</div>;
  if (!user) return <Navigate to="/login" replace />;
  if (staff && user.role === 'guest') return <Navigate to="/" replace />;
  return children;
}
