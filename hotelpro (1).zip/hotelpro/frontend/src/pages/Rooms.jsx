import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api, { errMsg } from '../api';
import { useAuth } from '../context/AuthContext.jsx';

const today = () => new Date().toISOString().slice(0, 10);

export default function Rooms() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [rooms, setRooms] = useState([]);
  const [dates, setDates] = useState({ checkIn: '', checkOut: '' });
  const [type, setType] = useState('');
  const [msg, setMsg] = useState({ text: '', variant: 'info' });

  const loadRooms = async () => {
    try {
      const params = {};
      if (type) params.type = type;
      if (dates.checkIn && dates.checkOut) Object.assign(params, dates);
      const { data } = await api.get('/rooms', { params });
      setRooms(data);
    } catch (err) {
      setMsg({ text: errMsg(err), variant: 'danger' });
    }
  };

  useEffect(() => {
    loadRooms();
  }, []);

  const book = async (roomId) => {
    if (!user) return navigate('/login');
    if (!dates.checkIn || !dates.checkOut) {
      return setMsg({ text: 'Select check-in and check-out dates first.', variant: 'warning' });
    }
    try {
      await api.post('/bookings', { roomId, ...dates });
      navigate('/my-bookings');
    } catch (err) {
      setMsg({ text: errMsg(err), variant: 'danger' });
    }
  };

  return (
    <div className="container py-4">
      <h2 className="mb-3">Find a room</h2>
      <div className="row g-2 mb-3">
        <div className="col-md-3">
          <input type="date" className="form-control" min={today()} value={dates.checkIn}
            onChange={(e) => setDates({ ...dates, checkIn: e.target.value })} />
        </div>
        <div className="col-md-3">
          <input type="date" className="form-control" min={dates.checkIn || today()} value={dates.checkOut}
            onChange={(e) => setDates({ ...dates, checkOut: e.target.value })} />
        </div>
        <div className="col-md-3">
          <select className="form-select" value={type} onChange={(e) => setType(e.target.value)}>
            <option value="">All types</option>
            <option value="single">Single</option>
            <option value="double">Double</option>
            <option value="deluxe">Deluxe</option>
            <option value="suite">Suite</option>
          </select>
        </div>
        <div className="col-md-3">
          <button className="btn btn-dark w-100" onClick={loadRooms}>Search</button>
        </div>
      </div>

      {msg.text && <div className={`alert alert-${msg.variant}`}>{msg.text}</div>}

      <div className="row g-4">
        {rooms.map((r) => (
          <div className="col-md-6 col-lg-4" key={r._id}>
            <div className="card room-card h-100 shadow-sm">
              <div className="card-body d-flex flex-column">
                <div className="d-flex justify-content-between">
                  <h5>Room {r.number}</h5>
                  <span className="badge bg-primary text-uppercase">{r.type}</span>
                </div>
                <p className="text-muted">{r.description}</p>
                <p className="small mb-1">👥 Up to {r.capacity} guests</p>
                <p className="small">{r.amenities.join(' · ')}</p>
                <div className="mt-auto d-flex justify-content-between align-items-center">
                  <strong>₹{r.price} / night</strong>
                  <button className="btn btn-success btn-sm" onClick={() => book(r._id)}>Book now</button>
                </div>
              </div>
            </div>
          </div>
        ))}
        {rooms.length === 0 && <p className="text-muted">No rooms available for the selected filters.</p>}
      </div>
    </div>
  );
}
