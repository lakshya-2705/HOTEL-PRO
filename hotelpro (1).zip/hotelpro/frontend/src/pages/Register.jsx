import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { errMsg } from '../api';

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '' });
  const [error, setError] = useState('');

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await register(form);
      navigate('/rooms');
    } catch (err) {
      setError(errMsg(err));
    }
  };

  return (
    <div className="container py-5" style={{ maxWidth: 420 }}>
      <h2 className="mb-4">Create account</h2>
      {error && <div className="alert alert-danger">{error}</div>}
      <form onSubmit={handleSubmit}>
        <input className="form-control mb-3" placeholder="Full name" required value={form.name} onChange={set('name')} />
        <input className="form-control mb-3" type="email" placeholder="Email" required value={form.email} onChange={set('email')} />
        <input className="form-control mb-3" placeholder="Phone" value={form.phone} onChange={set('phone')} />
        <input className="form-control mb-3" type="password" minLength={6} placeholder="Password (min 6)" required
          value={form.password} onChange={set('password')} />
        <button className="btn btn-primary w-100">Sign up</button>
      </form>
      <p className="mt-3">Already registered? <Link to="/login">Login</Link></p>
    </div>
  );
}
