# HotelPro – MERN Hotel Management System

## Setup
1. Install Node.js (LTS) and MongoDB Community (or use a MongoDB Atlas URI in backend/.env).
2. Backend:   cd backend  && npm install && npm run seed && npm run dev
3. Frontend:  cd frontend && npm install && npm run dev
4. Open http://localhost:5173

Seeded admin login: admin@hotelpro.com / admin123
