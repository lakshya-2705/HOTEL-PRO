import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <div className="container">
        <Link className="navbar-brand fw-bold" to="/">🏨 HotelPro</Link>
        <div className="d-flex align-items-center gap-3">
          <NavLink className="text-light text-decoration-none" to="/rooms">Rooms</NavLink>
          {user && <NavLink className="text-light text-decoration-none" to="/my-bookings">My Bookings</NavLink>}
          {user && user.role !== 'guest' && (
            <NavLink className="text-warning text-decoration-none" to="/admin">Dashboard</NavLink>
          )}
          {user ? (
            <>
              <span className="text-secondary small">Hi, {user.name}</span>
              <button className="btn btn-outline-light btn-sm" onClick={handleLogout}>Logout</button>
            </>
          ) : (
            <>
              <Link className="btn btn-outline-light btn-sm" to="/login">Login</Link>
              <Link className="btn btn-primary btn-sm" to="/register">Sign up</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
